#include <GLFW/glfw3.h>
#include <cmath>

// Function to handle rendering of the left triangle
void renderLeftTriangle() {
    glBegin(GL_TRIANGLES);
    glColor3f(1.0f, 0.0f, 0.0f);    // Red
    glVertex2f(-0.5f, -0.5f);
    glColor3f(0.0f, 1.0f, 0.0f);    // Green
    glVertex2f(-0.5f, 0.5f);
    glColor3f(0.0f, 0.0f, 1.0f);    // Blue
    glVertex2f(0.5f, -0.5f);
    glEnd();
}

// Function to handle rendering of the right triangle
void renderRightTriangle() {
    glBegin(GL_TRIANGLES);
    glColor3f(0.0f, 0.0f, 1.0f);    // Blue
    glVertex2f(0.5f, -0.5f);
    glColor3f(1.0f, 0.0f, 0.0f);    // Red
    glVertex2f(0.5f, 0.5f);
    glColor3f(0.0f, 1.0f, 0.0f);    // Green
    glVertex2f(-0.5f, -0.5f);
    glEnd();
}

int main() {
    // Initialize GLFW
    if (!glfwInit()) {
        return -1;
    }

    // Create a windowed mode window and its OpenGL context
    GLFWwindow* window = glfwCreateWindow(900, 700, "Two Colorful Triangles - CS-330 - Scott Dixon", 0, NULL);

    if (!window) {
        glfwTerminate();
        return -1;
    }

    // Make the window's context current
    glfwMakeContextCurrent(window);

    // Loop until the user closes the window
    while (!glfwWindowShouldClose(window)) {


        // Render the left triangle
        glViewport(100, 50, 600, 800); // Set viewport for left triangle
        glLoadIdentity(); // Reset transformation matrix
        renderLeftTriangle();

        // Render the right triangle
        glViewport(400, 0, 600, 800); // Set viewport for right triangle
        glLoadIdentity(); // Reset transformation matrix
        renderRightTriangle();

        // Swap front and back buffers
        glfwSwapBuffers(window);

        // Poll for and process events
        glfwPollEvents();
    }

    // Terminate GLFW
    glfwTerminate();

    return 0;
}


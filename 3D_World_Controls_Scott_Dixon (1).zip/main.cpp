
#include <iostream>
#include<glad/glad.h>
#include <GLFW/glfw3.h>


int main()
{
	return 0;
}
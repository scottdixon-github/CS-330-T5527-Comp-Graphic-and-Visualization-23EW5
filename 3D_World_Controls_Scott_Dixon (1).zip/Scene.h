#pragma once
#include "Shape.h"
#include "Mesh.h"

class SceneBuilder
{
public:
	static void UBuildScene(vector<GLMesh>& scene);
};




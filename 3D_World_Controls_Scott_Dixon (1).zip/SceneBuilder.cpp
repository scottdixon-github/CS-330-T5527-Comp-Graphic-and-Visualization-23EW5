
#include "Scene.h"
#include "Shape.h"
#include "Mesh.h"

using namespace std;

void SceneBuilder::UBuildScene(vector<GLMesh>& scene)
{

	// seed the rand() function once
	srand(time(nullptr));






	GLMesh plane_mesh;
	plane_mesh.p = {
		0.6f, 3.2f, 0.2f, 1.0f,             // color r, g, b, a (lime-green color)
		1.0f, 1.0f, 1.0f,                   // scale x, y, z
		0.0f, 0.0f, 0.0f, 1.0f,             // x amount of rotation, rotate x, y, z
		0.0f, 0.0f, 0.0f, 1.0f,             // y amount of rotation, rotate x, y, z
		0.0f, 0.0f, 0.0f, 1.0f,             // z amount of rotation, rotate x, y, z
		-1.5f, 0.2f, -3.0f,                 // translate x, y, z
		1.0f, 1.0f, 3.0f, 1.0f,
		1.0f, 1.0f, 1.0f, 3.5f                  // texture coordinate scales
	};

	plane_mesh.height = 3.0f;
	plane_mesh.length = 1.0f;
	plane_mesh.radius = 0.5f;
	plane_mesh.number_of_sides = 5;
	plane_mesh.texFilename = "texture\\bricks.png";

	ShapeBuilder::UBuildPyramid(plane_mesh);
	scene.push_back(plane_mesh);


	GLMesh triangle_mesh;
	plane_mesh.p = {
		0.6f, 0.0f, 0.2f, 1.0f,             // color r, g, b, a (lime-green color)
		1.0f, 1.0f, 1.0f,                   // scale x, y, z
		0.0f, 0.0f, 0.0f, 1.0f,             // x amount of rotation, rotate x, y, z
		0.0f, 0.0f, 0.0f, 1.0f,             // y amount of rotation, rotate x, y, z
		0.0f, 0.0f, 0.0f, 1.0f,             // z amount of rotation, rotate x, y, z
		-1.5f, 0.2f, -3.0f,                 // translate x, y, z
		1.0f, 1.0f, 3.0f, 1.0f,
		1.0f, 1.0f, 1.0f, 3.5f                  // texture coordinate scales
	};

	plane_mesh.height = 1.0f;
	plane_mesh.length = 6.0f;
	plane_mesh.radius = 0.5f;
	plane_mesh.number_of_sides = 5;
	plane_mesh.texFilename = "texture\\bricks.png";

	ShapeBuilder::UBuildPyramid(plane_mesh);
	scene.push_back(plane_mesh);









}
	

